<div class="text-center min-h-screen">
    <button wire:click="increment">+</button>
    <h1>{{ $count }}</h1>
</div>